package com.jeysoft.chuck_norris_jokes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
